import React from 'react';
import './App.css';
import Blog from './Blog';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Blog />
      </header>
    </div>
  );
}

export default App;